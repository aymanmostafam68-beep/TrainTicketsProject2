// Mock train data
const mockTrains = [
    {
        id: 1,
        name: 'Express 101',
        number: '101',
        from: 'Cairo',
        to: 'Alexandria',
        departure: '08:00',
        arrival: '10:30',
        duration: '2h 30m',
        seats: 120,
        price: 45,
        coachClass: 'second'
    },
    {
        id: 2,
        name: 'Premium 205',
        number: '205',
        from: 'Cairo',
        to: 'Alexandria',
        departure: '11:00',
        arrival: '13:45',
        duration: '2h 45m',
        seats: 85,
        price: 65,
        coachClass: 'first'
    },
    {
        id: 3,
        name: 'Luxury 320',
        number: '320',
        from: 'Cairo',
        to: 'Alexandria',
        departure: '14:00',
        arrival: '16:15',
        duration: '2h 15m',
        seats: 50,
        price: 85,
        coachClass: 'vip'
    },
    {
        id: 4,
        name: 'Express 102',
        number: '102',
        from: 'Alexandria',
        to: 'Cairo',
        departure: '09:00',
        arrival: '11:30',
        duration: '2h 30m',
        seats: 100,
        price: 45,
        coachClass: 'second'
    },
    {
        id: 5,
        name: 'Night Sleeper 440',
        number: '440',
        from: 'Cairo',
        to: 'Aswan',
        departure: '20:00',
        arrival: '08:00+1',
        duration: '12h',
        seats: 60,
        price: 120,
        coachClass: 'third'
    },
    {
        id: 6,
        name: 'Day Express 301',
        number: '301',
        from: 'Cairo',
        to: 'Aswan',
        departure: '07:00',
        arrival: '19:00',
        duration: '12h',
        seats: 95,
        price: 95,
        coachClass: 'first'
    }
];

// Current booking state
let currentBooking = {
    user: null,
    selectedTrain: null,
    passengerInfo: null,
    date: null,
    returnDate: null,
    tripType: 'oneway'
};

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    checkUserSession();
    setupEventListeners();
});

// Check if user is already logged in
function checkUserSession() {
    const user = localStorage.getItem('currentUser');
    if (user) {
        currentBooking.user = JSON.parse(user);
        showPage('trains-section');
        updateNavigation();
    } else {
        showPage('login-section');
    }
}

// Setup event listeners
function setupEventListeners() {
    // Login form
    document.getElementById('login-form').addEventListener('submit', handleLogin);

    // Logout button
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    // Train search
    document.getElementById('search-btn').addEventListener('click', handleSearchTrains);
    document.getElementById('departure-date').addEventListener('change', handleSearchTrains);
    document.getElementById('from-city').addEventListener('change', handleSearchTrains);
    document.getElementById('to-city').addEventListener('change', handleSearchTrains);
    
    // Trip type radio buttons
    document.querySelectorAll('input[name="trip-type"]').forEach(radio => {
        radio.addEventListener('change', handleTripTypeChange);
    });
    
    document.getElementById('return-date').addEventListener('change', handleSearchTrains);
    document.getElementById('train-number').addEventListener('change', handleSearchTrains);
    document.getElementById('coach-class').addEventListener('change', handleSearchTrains);

    // Payment form
    document.getElementById('payment-form').addEventListener('submit', handlePayment);

    // Format card number input
    document.getElementById('card-number').addEventListener('input', formatCardNumber);

    // Format expiry input
    document.getElementById('expiry').addEventListener('input', formatExpiry);

    // Format CVV input
    document.getElementById('cvv').addEventListener('input', formatCVV);
}

// Handle login
function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (email && password) {
        const user = {
            email: email,
            name: email.split('@')[0]
        };

        localStorage.setItem('currentUser', JSON.stringify(user));
        currentBooking.user = user;
        updateNavigation();
        showPage('trains-section');
        
        // Set today's date as default
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('departure-date').value = today;
        
        // Populate trains
        handleSearchTrains();
    }
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('currentUser');
    currentBooking = {
        user: null,
        selectedTrain: null,
        passengerInfo: null,
        date: null
    };
    document.getElementById('login-form').reset();
    showPage('login-section');
}

// Update navigation
function updateNavigation() {
    if (currentBooking.user) {
        document.getElementById('nav').style.display = 'flex';
        document.getElementById('welcome-user').textContent = `Welcome, ${currentBooking.user.name}`;
    } else {
        document.getElementById('nav').style.display = 'none';
    }
}

// Handle trip type change
function handleTripTypeChange() {
    const tripType = document.querySelector('input[name="trip-type"]:checked').value;
    const returnDateContainer = document.getElementById('return-date-container');
    currentBooking.tripType = tripType;

    if (tripType === 'roundtrip') {
        returnDateContainer.style.display = 'block';
    } else {
        returnDateContainer.style.display = 'none';
        document.getElementById('return-date').value = '';
        currentBooking.returnDate = null;
    }

    handleSearchTrains();
}

// Handle train search
function handleSearchTrains() {
    const date = document.getElementById('departure-date').value;
    const returnDate = document.getElementById('return-date').value;
    const from = document.getElementById('from-city').value;
    const to = document.getElementById('to-city').value;
    const trainNumber = document.getElementById('train-number').value;
    const coachClass = document.getElementById('coach-class').value;

    currentBooking.date = date;
    currentBooking.returnDate = returnDate;

    let filtered = mockTrains;

    if (from && to && from === to) {
        document.getElementById('trains-list').innerHTML = 
            '<p style="text-align: center; color: #64748b; padding: 2rem;">Please select different departure and arrival cities</p>';
        return;
    }

    if (from) {
        filtered = filtered.filter(train => train.from === from);
    }

    if (to) {
        filtered = filtered.filter(train => train.to === to);
    }

    if (trainNumber) {
        filtered = filtered.filter(train => train.number === trainNumber);
    }

    if (coachClass) {
        filtered = filtered.filter(train => train.coachClass === coachClass);
    }

    displayTrains(filtered);
}

// Display trains
function displayTrains(trains) {
    const trainsList = document.getElementById('trains-list');

    if (trains.length === 0) {
        trainsList.innerHTML = 
            '<p style="text-align: center; color: #64748b; padding: 2rem;">No trains available for the selected route</p>';
        return;
    }

    trainsList.innerHTML = trains.map(train => `
        <div class="train-card">
            <div class="train-header">
                <div class="train-route">
                    <h3>${train.from} <span class="train-arrow">→</span> ${train.to}</h3>
                </div>
                <div class="train-price">$${train.price}</div>
            </div>
            <div class="train-details">
                <div class="train-detail-item">
                    <strong>Train</strong>
                    <span>${train.name}</span>
                </div>
                <div class="train-detail-item">
                    <strong>Train Number</strong>
                    <span>${train.number}</span>
                </div>
                <div class="train-detail-item">
                    <strong>Coach Class</strong>
                    <span class="coach-class-badge">${capitalizeClass(train.coachClass)}</span>
                </div>
                <div class="train-detail-item">
                    <strong>Departure</strong>
                    <span>${train.departure}</span>
                </div>
                <div class="train-detail-item">
                    <strong>Arrival</strong>
                    <span>${train.arrival}</span>
                </div>
                <div class="train-detail-item">
                    <strong>Duration</strong>
                    <span>${train.duration}</span>
                </div>
                <div class="train-detail-item">
                    <strong>Available Seats</strong>
                    <span>${train.seats}</span>
                </div>
            </div>
            <button class="btn-select-train" onclick="selectTrain(${train.id})">Select Train</button>
        </div>
    `).join('');
}

// Select a train
function selectTrain(trainId) {
    const train = mockTrains.find(t => t.id === trainId);
    if (train) {
        currentBooking.selectedTrain = train;
        displayPaymentSummary();
        showPage('payment-section');
    }
}

// Display payment summary
function displayPaymentSummary() {
    const train = currentBooking.selectedTrain;
    const date = currentBooking.date || new Date().toISOString().split('T')[0];
    const returnDate = currentBooking.returnDate;
    const tripType = currentBooking.tripType;

    let summaryHTML = `
        <div class="summary-item">
            <div class="summary-label">Trip Type</div>
            <div class="summary-value">${tripType === 'roundtrip' ? 'Round Trip' : 'One Way'}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Route</div>
            <div class="summary-value">${train.from} → ${train.to}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Train</div>
            <div class="summary-value">${train.name} (${train.number})</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Coach Class</div>
            <div class="summary-value">${capitalizeClass(train.coachClass)}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Departure</div>
            <div class="summary-value">${train.departure}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Arrival</div>
            <div class="summary-value">${train.arrival}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Departure Date</div>
            <div class="summary-value">${new Date(date).toLocaleDateString()}</div>
        </div>
    `;

    if (tripType === 'roundtrip' && returnDate) {
        summaryHTML += `
        <div class="summary-item">
            <div class="summary-label">Return Date</div>
            <div class="summary-value">${new Date(returnDate).toLocaleDateString()}</div>
        </div>
        `;
    }

    summaryHTML += `
        <div class="summary-item">
            <div class="summary-label">Number of Passengers</div>
            <div class="summary-value">1</div>
        </div>
        <div class="summary-total">
            <span>Price per Ticket</span>
            <span>$${train.price}</span>
        </div>
    `;

    document.getElementById('summary-details').innerHTML = summaryHTML;
    document.getElementById('total-amount').textContent = `$${train.price.toFixed(2)}`;
}

// Handle payment
function handlePayment(e) {
    e.preventDefault();

    const passengerInfo = {
        name: document.getElementById('passenger-name').value,
        id: document.getElementById('passenger-id').value,
        phone: document.getElementById('passenger-phone').value
    };

    currentBooking.passengerInfo = passengerInfo;

    // Show confirmation
    showConfirmation();
    showPage('confirmation-section');
}

// Show confirmation
function showConfirmation() {
    const train = currentBooking.selectedTrain;
    const date = currentBooking.date || new Date().toISOString().split('T')[0];
    const returnDate = currentBooking.returnDate;
    const tripType = currentBooking.tripType;
    const passenger = currentBooking.passengerInfo;

    let confirmationHTML = `
        <div class="confirmation-item">
            <strong>Booking Reference</strong>
            <span>#${generateBookingReference()}</span>
        </div>
        <div class="confirmation-item">
            <strong>Passenger Name</strong>
            <span>${passenger.name}</span>
        </div>
        <div class="confirmation-item">
            <strong>Train</strong>
            <span>${train.name} (${train.number})</span>
        </div>
        <div class="confirmation-item">
            <strong>Coach Class</strong>
            <span>${capitalizeClass(train.coachClass)}</span>
        </div>
        <div class="confirmation-item">
            <strong>Trip Type</strong>
            <span>${tripType === 'roundtrip' ? 'Round Trip' : 'One Way'}</span>
        </div>
        <div class="confirmation-item">
            <strong>Route</strong>
            <span>${train.from} → ${train.to}</span>
        </div>
        <div class="confirmation-item">
            <strong>Departure Date</strong>
            <span>${new Date(date).toLocaleDateString()}</span>
        </div>
    `;

    if (tripType === 'roundtrip' && returnDate) {
        confirmationHTML += `
        <div class="confirmation-item">
            <strong>Return Date</strong>
            <span>${new Date(returnDate).toLocaleDateString()}</span>
        </div>
        `;
    }

    confirmationHTML += `
        <div class="confirmation-item">
            <strong>Departure Time</strong>
            <span>${train.departure}</span>
        </div>
        <div class="confirmation-item">
            <strong>Seat Number</strong>
            <span>${generateSeatNumber()}</span>
        </div>
        <div class="confirmation-item">
            <strong>Ticket Price</strong>
            <span>$${train.price}</span>
        </div>
    `;

    document.getElementById('confirmation-details').innerHTML = confirmationHTML;
}

// Go back to trains
function goBackToTrains() {
    // Reset forms
    document.getElementById('payment-form').reset();
    currentBooking.selectedTrain = null;
    currentBooking.passengerInfo = null;
    
    // Show trains page
    showPage('trains-section');
}

// Show page
function showPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.style.display = 'none';
    });

    // Show selected page
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) {
        selectedPage.style.display = 'block';
    }
}

// Generate booking reference
function generateBookingReference() {
    return Math.random().toString(36).substr(2, 9).toUpperCase();
}

// Generate seat number
function generateSeatNumber() {
    const car = Math.floor(Math.random() * 10) + 1;
    const seat = Math.floor(Math.random() * 50) + 1;
    return `Car ${car}, Seat ${seat}`;
}

// Format card number (add spaces every 4 digits)
function formatCardNumber(e) {
    let value = e.target.value.replace(/\s/g, '');
    let formatted = value.replace(/(\d{4})/g, '$1 ').trim();
    e.target.value = formatted.substr(0, 19);
}

// Format expiry (MM/YY)
function formatExpiry(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.substr(0, 2) + '/' + value.substr(2, 2);
    }
    e.target.value = value;
}

// Format CVV (numbers only)
function formatCVV(e) {
    e.target.value = e.target.value.replace(/\D/g, '');
}

// Capitalize coach class name
function capitalizeClass(coachClass) {
    const classNames = {
        'first': 'First Class',
        'second': 'Second Class',
        'third': 'Third Class',
        'vip': 'VIP'
    };
    return classNames[coachClass] || coachClass;
}
